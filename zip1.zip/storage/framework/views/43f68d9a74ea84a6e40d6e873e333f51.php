<?php Basset::basset('https://unpkg.com/@digitallyhappy/backstrap@0.5.1/dist/css/legacy.css'); ?>
<?php Basset::basset('https://cdnjs.cloudflare.com/ajax/libs/noty/3.1.4/noty.min.css'); ?>


<?php Basset::bassetArchive(base_path('vendor/backpack/theme-coreuiv2/resources/assets/fonts/source-sans-3.052R.tar.gz'), 'source-sans-pro'); ?>
<?php Basset::basset(base_path('vendor/backpack/theme-coreuiv2/resources/assets/css/source-sans-pro.css')); ?>


<?php Basset::basset(base_path('vendor/backpack/theme-coreuiv2/resources/assets/css/coreuiv2.css')); ?><?php /**PATH B:\Creative Universe\Projets\Hackathon momo 2023\dona\vendor/backpack/theme-coreuiv2/resources/views/inc/theme_styles.blade.php ENDPATH**/ ?>