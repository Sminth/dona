<header class="<?php echo e(backpack_theme_config('classes.header')); ?>">
  
  <button class="navbar-toggler sidebar-toggler d-lg-none mr-auto ml-3" type="button" data-toggle="sidebar-show" aria-label="<?php echo e(trans('backpack::base.toggle_navigation')); ?>">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="<?php echo e(url(backpack_theme_config('home_link'))); ?>" title="<?php echo e(backpack_theme_config('project_name')); ?>">
    <?php echo backpack_theme_config('project_logo'); ?>

  </a>
  <button class="navbar-toggler sidebar-toggler d-md-down-none" type="button" data-toggle="sidebar-lg-show" aria-label="<?php echo e(trans('backpack::base.toggle_navigation')); ?>">
    <span class="navbar-toggler-icon"></span>
  </button>

  <?php echo $__env->make(backpack_view('inc.menu'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<?php /**PATH B:\Creative Universe\Projets\Hackathon momo 2023\dona\vendor/backpack/theme-coreuiv2/resources/views/inc/main_header.blade.php ENDPATH**/ ?>