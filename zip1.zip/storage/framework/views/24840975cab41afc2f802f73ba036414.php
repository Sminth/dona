<?php Basset::basset("https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"); ?>
<?php Basset::basset('https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.2/js/bootstrap.min.js'); ?>
<?php Basset::basset('https://unpkg.com/@coreui/coreui@2.1.16/dist/js/coreui.js'); ?>
<?php /**PATH B:\Creative Universe\Projets\Hackathon momo 2023\dona\vendor/backpack/theme-coreuiv2/resources/views/inc/theme_scripts.blade.php ENDPATH**/ ?>