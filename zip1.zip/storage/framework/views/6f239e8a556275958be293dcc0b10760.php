<?php $__env->startSection('content'); ?>
<link href="https://api.mapbox.com/mapbox-gl-js/v3.0.1/mapbox-gl.css" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/map.css')); ?>" rel="stylesheet">
<script src="https://api.mapbox.com/mapbox-gl-js/v3.0.1/mapbox-gl.js"></script>
<style>

</style>

<div style="position: relative;height:80vh">
    <div id="map"></div>
    <div id="sidebar" class="shadow-lg"></div>

    <div id="legend">


        <div id="vote">
            <canvas id="votesChart"></canvas>
        </div>

        <div id="participation-rate" class="participation">
            <canvas id="participationChart"></canvas>
        </div>

        
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="<?php echo e(asset('assets/js/map.js')); ?>"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH B:\Creative Universe\Projets\Hackathon momo 2023\dona\resources\views/carto.blade.php ENDPATH**/ ?>