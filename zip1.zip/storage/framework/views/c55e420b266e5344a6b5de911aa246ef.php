<!DOCTYPE html>
<html lang="fr">

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" id="app-style" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/fontawesome-all.css')); ?>" id="app-style" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/custom-animate.css')); ?>" id="app-style" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/animate.css')); ?>" id="app-style" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/jquery-ui-1.9.2.custom.min.css')); ?>" id="app-style" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/nice-select.css')); ?>" id="app-style" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/flaticon.css')); ?>" id="app-style" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/owl.css')); ?>" id="app-style" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/jquery.fancybox.min.css')); ?>" id="app-style" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/swiper.min.css')); ?>" id="app-style" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/custom-menu.css')); ?>" id="app-style" rel="stylesheet">


    <link href="<?php echo e(asset('assets/css/style.css')); ?>" id="app-style" rel="stylesheet">
    <!-- Responsive File -->
    <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" id="app-style" rel="stylesheet">

    <!-- Color File -->
    <link href="<?php echo e(asset('assets/css/color.css')); ?>" id="app-style" rel="stylesheet">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap"
        rel="stylesheet">


    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">
    <link rel="icon" href="assets/images/favicon.png" type="image/x-icon">

    <?php echo $__env->yieldContent('extra-css'); ?>



    <title>Dona - Accueil</title>

</head>

<body lass="body-wrapper">

    <div class="page-wrapper">

        <header class="main-header header-style-one header-s-two">
            <div class="header-top">
                <div class="header-container-box">
                    <div class="wrapper-box">
                        <div class="left-column">
                            <ul class="contact-info box-s-two">
                                <li><a href="mailto:hotline@gmail.com"><i
                                            class="far fa-envelope"><span>Email:</span></i>virtus225one@gmail.com</a>
                                </li>
                                <li class="crl-1">|</li>
                            </ul>
                        </div>
                        <div class="right-column box-s-two">
                            <div class="text">Entreprise caritative à but non lucratif</div>
                            <ul>
                                <li><a href="tel:09806764956"><span>Contactez nous : </span> +225 (07) 88364403</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Header Upper -->
            <div class="header-upper">
                <div class="header-container-box">
                    <div class="inner-container">
                        <div class="left-column">
                            <div class="logo">
                                <a href="/">
                                    <img style="width: 100px;height:90px" src="<?php echo e(asset('assets/images/lgo.png')); ?>"
                                        alt="">
                                    
                                </a>
                            </div>
                            <!--Nav Box-->
                            <div class="nav-outer">
                                <!--Mobile Navigation Toggler-->
                                <div class="mobile-nav-toggler"><img
                                        src="<?php echo e(asset('assets/images/icons/icon-bar.png')); ?>" alt=""></div>

                                <nav class="main-menu navbar-expand-md navbar-light">
                                    <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                        <ul class="navigation">
                                            <li><a href="/">Accueil </a>

                                            </li>

                                            <li><a href="/causes">Nos Causes</a>

                                            </li>
                                            <li class="#"><a href="/cartographie">Cartographie des causes</a>

                                            </li>
                                            
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>


                        <div class="right-column">

                            
                            <a href="/causes" class="primary_btn style-seven donate_button">Faire une Dona<i
                                    class="far fa-heart"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="sticky-header">
                <div class="header-upper">
                    <div class="header-container-box">
                        <div class="inner-container">
                            <div class="left-column">
                                <div class="logo">
                                    <a href="/">
                                        <img style="width: 100px;height:90px"
                                            src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
                                        
                                    </a>
                                </div>
                                <div class="nav-outer">
                                    <div class="mobile-nav-toggler"><img src="assets/images/icons/icon-bar.png"
                                            alt=""></div>

                                    <nav class="main-menu navbar-expand-md navbar-light">
                                    </nav>

                                </div>
                            </div>


                            <div class="right-column">

                                
                                <a href="/causes" class="primary_btn style-seven">Faire une Dona<i
                                        class="far fa-heart"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Sticky Menu -->

            <!-- Mobile Menu  -->
            <div class="mobile-menu">
                <div class="menu-backdrop"></div>
                <div class="close-btn"><i class="icon far fa-times"></i></div>

                <nav class="menu-box">
                    <div class="nav-logo">
                        <a href="">
                            <h1 style="color: white;">DONA</h1>
                        </a>
                    </div>
                    <div class="menu-outer"></div>
                </nav>
            </div><!-- End Mobile Menu -->

            <div class="nav-overlay"></div>
        </header>

        <section class="header-widget-sidebar close-sidebar" style="z-index: 9999999999999999999999999999">
            <div class="wrapper-box" style="z-index: 9999999999999999999999999999">
                <div class="content-wrapper" style="z-index: 9999999999999999999999999999">
                    <div class="header-widget-sidebar-close"><span class="far fa-times"></span></div>
                    <div class="about-widget widget">
                        <div class="logo" style="text-align: center;align-items:center">
                            <img style="height: 100px" id="donorgimg" src="<?php echo e(asset('assets/images/logo.png')); ?>" />
                            <h6 style="color: white;margin-top:5px" id="donorg">Dona</h6>
                        </div>
                        <div class="text" id="dontitre" style="text-align: center;font-size:18px"> --- </div>
                    </div>
                    <div class="footer-widget-item recent-news-widget widget">
                        <div class="counter-block-three-single style-seven">
                            <h4 class="title">Collecté<span style="color: white" id="doncollecte"> -- </span> f</h4>
                            <div class="bar">
                                <div class="count-text clr3"> <span id="donpercenttext">--</span> % </div>
                                <div class="bar-inner bg4 count-bar" id="donpercent" data-percent="0"> </div>
                            </div>
                            <ul>
                                <li>Objectif<span class="crl4" id="donobj"> -- </span> f</li>
                                
                                <li>Reste<span class="crl3" id="donreste"> -- </span> f</li>
                            </ul>
                        </div>
                        <div class="project-o" style="margin-top:15px">
                            <ul class="donation-ant" style="margin-top:15px">
                                <li class="price-value donation-form-one-price-value" style=""
                                    onclick="insertMontant(10000)" data-dollars='1000'>10 000 f</li>
                                    <li class="price-value donation-form-one-price-value"
                                    onclick="insertMontant(50000)" data-dollars='1000'>50 000 f</li>
                                    <li class="price-value donation-form-one-price-value"
                                    onclick="insertMontant(100000)" data-dollars='1000'>100 000 f</li>
                            </ul>
                        </div>


                        <form action="<?php echo e(route('paye')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>


                            <div class="form" style="position: relative;width:100%;margin-top: 20px">
                                <input name="montant" class="input" placeholder="Entrez votre montant"
                                    id="montant" required type="number">
                                <span class="input-border"></span>
                            </div>
                            <div class="form" style="position: relative;width:100%;margin-top: 20px">
                                <input name="numero" class="input" placeholder="Entrez votre numero (ex: 0574386145)"
                                    id="montant" required type="tel" pattern="[0-9]{10}" required="Veuillez rentrer un numero a 10 chiffres svp">
                                <span class="input-border"></span>
                            </div>
                            <div class="checkbox-wrapper" style="margin-top: 20px;margin-bottom: 20px">
                                <input id="terms-checkbox-37" name="informe" type="checkbox"
                                    style="background: white">
                                <label onclick="document.getElementById('informe').style.display=='none'?document.getElementById('informe').style.display='block':document.getElementById('informe').style.display='none'" class="terms-label" for="terms-checkbox-37">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 200 200"
                                        class="checkbox-svg">
                                        <mask fill="white" id="path-1-inside-1_476_5-37">
                                            <rect height="200" width="200"></rect>
                                        </mask>
                                        <rect mask="url(#path-1-inside-1_476_5-37)" stroke-width="40"
                                            class="checkbox-box" height="200" width="200"></rect>
                                        <path stroke-width="15" d="M52 111.018L76.9867 136L149 64"
                                            class="checkbox-tick"></path>
                                    </svg>
                                    <span
                                        class="label-text">être informer des impacts de mon don</span>
                                </label>
                            </div>



                            <div id="informe" style="display: none">
                                <input class="id" name="id" id="id" type="hidden">

                                <div class="form" style="position: relative;width:100%">
                                    <input class="input" name="email" placeholder="Entrez votre mail" type="email">
                                    <span class="input-border"></span>
                                </div>
                                <div class="form" style="position: relative;width:100%">
                                    <input class="input" name="nom" placeholder="Entrez votre nom (optionnel)" type="text">
                                    <span class="input-border"></span>
                                </div>
                            </div>
                            <center>
                                <div class="from-button"><button class="primary_btn-one donate_button">Faire une
                                        dona<i class="far fa-heart"></i></button></div>
                            </center>
                        </form>

                        
                    </div>
                    
                </div>
            </div>
        </section>


        <?php echo $__env->yieldContent('content'); ?>



        <footer class="main-footer">

            <!-- start footer conter section -->
            <div class="section-footer-countr-section">
                <div class="theme_container">
                    <img style="width: 100px;height:90px" src="<?php echo e(asset('assets/images/logo.png')); ?>"
                        alt=""> changer une vie
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="footer-counter-block">
                                <div class="count-outer count-box">
                                    <span class="count-text" data-speed="3000" data-stop="5000000">0</span><span
                                        class="plus"> f+</span>
                                    <span class="crl3">
                                        Levé pour un don</span>
                                </div>
                            </div>

                        </div>
                        <div class="col-lg-6">
                            <div class="donation-form-one-form-wrap s-two">
                                <ul class="donation-form-one-form-wrap-ul donate_form_amount_wrap">
                                    <li class="donation-form-one-price-value" data-dollars='1000'>100 000 F</li>
                                    <li class="donation-form-one-price-value" data-dollars='500'>50 000 F</li>
                                    <li class="donation-form-one-price-value" data-dollars='100'>30 000 F</li>
                                    <li class="donation-form-one-price-value" data-dollars='25'>15 000 F</li>
                                    

                                    <li class="other-input"></li>
                                </ul>
                                <div class="donation-form-one-submit-btn"><button
                                        class="primary_btn-one donate_button" type="submit">Dona<i
                                            class="far fa-heart"></i></button></div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            


            <!--Start Main Footer Bottom -->
            <div class="main-footer-bottom">
                <div class="theme_container">
                    <div class="main-footer-bottom-inner">
                        <ul>
                            <li><a href="#">Politique de confidentialité</a></li>
                            

                        </ul>
                        <div class="text">
                            <p>Copyright © 2023 Dona. Tout droits Reservé.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Main Footer Bottom -->
        </footer>

    </div>


    <a href="# " id="topp" class="back-to-top " data-wow-duration="1.0s " data-wow-delay="1.0s ">
        <i class="fas fa-angle-up "></i>
    </a>

    <script>
        function show(cause) {
            console.log(111, cause)
            // document.getElementById('topp').display='none'

            document.getElementById('id').value = cause['id']
            document.getElementById('donorgimg').src = window.location.origin + '/storage/' + cause['organisations']['logo']
            document.getElementById('donorg').innerText = cause['organisations']['nom']
            document.getElementById('dontitre').innerText = cause['libelle']
            document.getElementById('doncollecte').innerText = parseInt(cause['collecte'] ?? 0)
            document.getElementById('donobj').innerText = parseInt(cause['objectif'] ?? 0)
            document.getElementById('donreste').innerText = parseInt(cause['objectif'] ?? 0) - parseInt(cause['collecte'] ??
                0)
            document.getElementById('donpercenttext').innerText = Number.parseFloat((parseInt(cause['collecte'] ?? 0) / parseInt(cause[
                'objectif'] ?? 0)) * 100).toFixed(0);
            document.getElementById('donpercent').setAttribute("data-percent", (parseInt(cause['collecte'] ?? 0) / parseInt(
                cause['objectif'] ?? 0)) * 100 + "%")

        }

        function insertMontant(mtn) {
            document.getElementById('montant').value = mtn

        }
    </script>
    <style>
        .form {
            --width-of-input: 200px;
            --border-height: 1px;
            --border-before-color: rgba(221, 221, 221, 0.39);
            --border-after-color: #FF7200;
            --input-hovered-color: #4985e01f;
            position: relative;
            width: var(--width-of-input);
        }

        /* styling of Input */
        .input {
            color: #fff;
            font-size: 0.9rem;
            background-color: transparent;
            width: 100%;
            box-sizing: border-box;
            padding-inline: 0.5em;
            padding-block: 0.7em;
            border: none;
            border-bottom: var(--border-height) solid var(--border-before-color);
        }

        /* styling of animated border */
        .input-border {
            position: absolute;
            background: var(--border-after-color);
            width: 0%;
            height: 2px;
            bottom: 0;
            left: 0;
            transition: 0.3s;
        }

        /* Hover on Input */
        input:hover {
            background: var(--input-hovered-color);
        }

        input:focus {
            outline: none;
        }

        /* here is code of animated border */
        input:focus~.input-border {
            width: 100%;
        }

        /* === if you want to do animated border on typing === */
        /* remove input:focus code and uncomment below code */
        /* input:valid ~ .input-border{
  width: 100%;
} */




        .checkbox-wrapper input[type="checkbox"] {
            display: none;
        }

        .checkbox-wrapper .terms-label {
            cursor: pointer;
            display: flex;
            align-items: center;
        }

        .checkbox-wrapper .terms-label .label-text {
            margin-left: 10px;
        }

        .checkbox-wrapper .checkbox-svg {
            width: 20px;
            height: 20px;
        }

        .checkbox-wrapper .checkbox-box {
            fill: #fff;
            stroke: #FF7200;
            stroke-dasharray: 800;
            stroke-dashoffset: 800;
            transition: stroke-dashoffset 0.6s ease-in;
        }

        .checkbox-wrapper .checkbox-tick {
            stroke: #FF7200;
            stroke-dasharray: 172;
            stroke-dashoffset: 172;
            transition: stroke-dashoffset 0.6s ease-in;
        }

        .checkbox-wrapper input[type="checkbox"]:checked+.terms-label .checkbox-box,
        .checkbox-wrapper input[type="checkbox"]:checked+.terms-label .checkbox-tick {
            stroke-dashoffset: 0;
        }
    </style>

    
    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.fancybox.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/isotope.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/appear.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.ajaxchimp.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/knob.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/TweenMax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/active.js')); ?>"></script>



    <?php echo $__env->yieldContent('extra-js'); ?>

</body>

</html>
<?php /**PATH B:\Creative Universe\Projets\Hackathon momo 2023\dona\resources\views/layouts/app.blade.php ENDPATH**/ ?>