<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>QR Code</title>
</head>
<body>
    <h1>Votre QR Code</h1>
    <img src="{{ route('qr.code.generate') }}" alt="QR Code">
</body>
</html>
    